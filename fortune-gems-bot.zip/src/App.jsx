import React, { useState } from 'react'

export default function App() {
  const [logs, setLogs] = useState([])

  const generateSignal = () => {
    const outcomes = ['WIN 🔥', 'LOSE ❌', 'TRY AGAIN ⚡']
    const pick = outcomes[Math.floor(Math.random() * outcomes.length)]
    setLogs([`Signal: ${pick} | ${new Date().toLocaleTimeString()}`, ...logs])
  }

  return (
    <div style={{ background: '#0e0e1a', color: 'white', minHeight: '100vh', padding: '20px', fontFamily: 'Segoe UI' }}>
      <h1 style={{ textAlign: 'center' }}>🎰 Fortune Gems Bot</h1>
      <div style={{ textAlign: 'center', margin: '20px' }}>
        <button onClick={generateSignal} style={{ padding: '10px 20px', fontSize: '18px', borderRadius: '8px', cursor: 'pointer' }}>
          Generate Signal
        </button>
      </div>
      <div style={{ maxWidth: '500px', margin: '0 auto' }}>
        <h2>Logs:</h2>
        <ul>
          {logs.map((log, idx) => (
            <li key={idx}>{log}</li>
          ))}
        </ul>
      </div>
    </div>
  )
}
